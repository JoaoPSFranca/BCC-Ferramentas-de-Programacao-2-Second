# O Projeto: "OS-Manager"

## As 4 Entidades do Banco (Modelagem JPA)

1. Usuario (O Mecânico/Gerente):
- Atributos: id (String UUID), login, senha, role (ADMIN ou USER).
- Regra: Tem que implementar UserDetails.

2. Servico (O Catálogo da oficina):
- Atributos: id (Long), descricao, precoBase (BigDecimal).
- Validações obrigatórias: @NotBlank na descrição e @DecimalMin(value = "10.00") no preço.

3. OrdemServico (A Ficha da Moto/Carro):
- Atributos: id (Long), placaVeiculo (String), dataAbertura (LocalDateTime), status (Enum: ABERTA, CONCLUIDA), valorTotal (BigDecimal).
- Relacionamento A: @ManyToOne com Usuario (O mecânico responsável).
- Relacionamento B: @OneToMany(mappedBy = "ordemServico") com a lista de ItemOS.

4. ItemOS (O que foi feito no carro):
- Atributos: id (Long), quantidadeHoras (Integer), subtotal (BigDecimal).
- Relacionamento A: @ManyToOne com Servico.
- Relacionamento B: @ManyToOne com OrdemServico (Atenção: coloque o @JsonIgnore aqui!).